# Playing-with-Vectors
Learning to convert images to Vectors using Python
